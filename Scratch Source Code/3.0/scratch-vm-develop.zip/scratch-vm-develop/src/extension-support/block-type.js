const BlockType = {
    BOOLEAN: 'Boolean',
    COMMAND: 'command',
    CONDITIONAL: 'conditional',
    HAT: 'hat',
    REPORTER: 'reporter'
};

module.exports = BlockType;
