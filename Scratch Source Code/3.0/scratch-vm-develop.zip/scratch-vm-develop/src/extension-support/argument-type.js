const ArgumentType = {
    ANGLE: 'angle',
    BOOLEAN: 'Boolean',
    COLOR: 'color',
    NUMBER: 'number',
    STRING: 'string'
};

module.exports = ArgumentType;
