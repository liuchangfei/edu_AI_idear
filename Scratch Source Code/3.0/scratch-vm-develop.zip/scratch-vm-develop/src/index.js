const VirtualMachine = require('./virtual-machine');

module.exports = VirtualMachine;
